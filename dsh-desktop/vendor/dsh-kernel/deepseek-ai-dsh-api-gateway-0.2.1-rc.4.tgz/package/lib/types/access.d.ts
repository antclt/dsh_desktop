/**
 * Resource resolution for non-owner access decisions: the resources one call
 * or one forwarded event touches, read from Typert-validated arguments before
 * any lookup or Context resolves them.
 * @module @deepseek-ai/dsh-api-gateway/src/access
 */
import type { InvocationDescriptor, RemoteAccessResource, TypertRegistryContract, TypertResourceReader } from '@deepseek-ai/dsh-typert-protocol';
/**
 * Resolve the resources one call touches. For each resource kind, a
 * `resources` reader of the method wins; otherwise every lookup parameter
 * whose provider declares the kind contributes its wire resource id, and so
 * does the Context identity of a Context method whose Host adapter declares
 * the kind; otherwise the kind's default field registered in
 * `typert.resources` is read from a top-level argument or, failing that,
 * from the first object argument.
 * @param typert - registry holding default fields, lookup providers, and Host Context adapters.
 * @param readers - the method's `resources` readers, or `undefined` when it declares none.
 * @param descriptor - receiver, parameter order, lookups, and cancellation slot of the method.
 * @param args - named arguments matched to the descriptor's field set: JSON
 *   arguments as their Typert codecs validated them, lookup and Context
 *   identities as wire values.
 * @param signal - value placed in the cancellation slot of the positional arguments.
 * @returns the touched resources, the global resource alone when none;
 *   `undefined` when the resources are invalid: a reader throws or returns
 *   an empty list, a default field holds an array, or a resource id is not a
 *   non-empty string.
 */
export declare function callResources(typert: Pick<TypertRegistryContract, 'contexts' | 'lookups' | 'resources'>, readers: Readonly<Record<string, TypertResourceReader>> | undefined, descriptor: Pick<InvocationDescriptor, 'cancellation' | 'invocation' | 'parameters'>, args: Readonly<Record<string, unknown>>, signal: AbortSignal): readonly RemoteAccessResource[] | undefined;
/**
 * Resolve the resources one forwarded event notification touches. An event
 * carries every resource it declares, so a reader returning `undefined`
 * makes the notification invalid instead of a global one.
 * @param readers - the event entry's declared readers, or `undefined` when it declares none.
 * @param args - the event's validated JSON arguments, passed to each reader as its positional arguments.
 * @returns the global resource alone without readers, including an empty
 *   reader set; otherwise the touched resources; `undefined` when the
 *   resources are invalid: a resource id is missing or malformed.
 */
export declare function eventResources(readers: Readonly<Record<string, TypertResourceReader>> | undefined, args: readonly unknown[]): readonly RemoteAccessResource[] | undefined;
//# sourceMappingURL=access.d.ts.map