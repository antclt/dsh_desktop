/** Copy for the More menu rows: navigation actions, and Creator draft prompts per region. */
export declare const en: {
    readonly install: "Browse other plugins";
    readonly create: "Create your plugin";
    readonly 'createPrompt.sidebar': "Create a DSH plugin with a left sidebar entry.";
    readonly 'createPrompt.conversation': "Create a DSH conversation view plugin.";
    readonly 'createPrompt.rightbar': "Create a DSH plugin with a right sidebar entry.";
};
/** Chinese counterpart of the entry-customization dictionary. */
export declare const zh: Record<keyof typeof en, string>;
//# sourceMappingURL=locales.d.ts.map