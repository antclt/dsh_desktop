/**
 * `model` namespace dictionaries.
 *
 * `trigger.selectAria` intentionally matches `trigger.fallback` but remains a
 * separate key: the visible fallback label and the accessible name of
 * an unset trigger are free to diverge per locale, and folding it into
 * `trigger.aria` would announce the degenerate "Select model, current Select
 * model".
 */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'provider.account': string;
    'command.label': string;
    'command.description': string;
    'option.loadError': string;
    'trigger.fallback': string;
    'trigger.loading': string;
    'trigger.selectAria': string;
    'trigger.aria': string;
    'trigger.ariaEffort': string;
    'menu.aria': string;
    'menu.model': string;
    'menu.effort': string;
    'effort.providerDefault': string;
    'status.loading': string;
    'error.action': string;
    'error.sessionInUse': string;
    'action.reload': string;
    'warning.groupLoad': string;
    'search.placeholder': string;
    'search.clear': string;
    'search.empty': string;
    'empty.models': string;
    'empty.efforts': string;
};
/** The model namespace key union. */
export type ModelKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    'provider.account': string;
    'command.label': string;
    'command.description': string;
    'option.loadError': string;
    'trigger.fallback': string;
    'trigger.loading': string;
    'trigger.selectAria': string;
    'trigger.aria': string;
    'trigger.ariaEffort': string;
    'menu.aria': string;
    'menu.model': string;
    'menu.effort': string;
    'effort.providerDefault': string;
    'status.loading': string;
    'error.action': string;
    'error.sessionInUse': string;
    'action.reload': string;
    'warning.groupLoad': string;
    'search.placeholder': string;
    'search.clear': string;
    'search.empty': string;
    'empty.models': string;
    'empty.efforts': string;
};
//# sourceMappingURL=locales.d.ts.map